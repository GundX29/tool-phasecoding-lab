import numpy as np
import librosa
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.stats import entropy

def analyze_phase(audio_file, segment_length=2048):
    # Đọc file âm thanh
    y, sr = librosa.load(audio_file, sr=None)
    
    # Chia tín hiệu thành các đoạn ngắn
    n_segments = len(y) // segment_length
    phase_variances = []
    phase_entropies = []
    
    for i in range(n_segments):
        segment = y[i * segment_length:(i + 1) * segment_length]
        
        # Tính FFT và lấy phổ pha
        fft_result = np.fft.fft(segment)
        phase = np.angle(fft_result)
        
        # Tính độ biến thiên của pha
        phase_variance = np.var(phase)
        phase_variances.append(phase_variance)
        
        # Tính entropy của pha
        hist, _ = np.histogram(phase, bins=50, density=True)
        phase_entropy = entropy(hist)
        phase_entropies.append(phase_entropy)
    
    # Phân tích thống kê
    mean_variance = np.mean(phase_variances)
    std_variance = np.std(phase_variances)
    mean_entropy = np.mean(phase_entropies)
    std_entropy = np.std(phase_entropies)
    
    print(f"Mean phase variance: {mean_variance:.6f}")
    print(f"Std of phase variance: {std_variance:.6f}")
    print(f"Mean phase entropy: {mean_entropy:.6f}")
    print(f"Std of phase entropy: {std_entropy:.6f}")
    
    # Phát hiện đỉnh bất thường
    threshold = mean_variance + 2 * std_variance
    anomalies = [var for var in phase_variances if var > threshold]
    
    # Phân tích tự tương quan để tìm mẫu lặp lại
    autocorr = np.correlate(phase_variances - np.mean(phase_variances), 
                           phase_variances - np.mean(phase_variances), mode='full')
    autocorr = autocorr[len(autocorr)//2:]  # Lấy nửa dương
    peaks, _ = find_peaks(autocorr, height=np.max(autocorr) * 0.3)
    
    # Vẽ biểu đồ
    plt.figure(figsize=(12, 8))
    
    # Biểu đồ độ biến thiên pha
    plt.subplot(3, 1, 1)
    plt.plot(phase_variances, label="Phase Variance")
    plt.axhline(y=threshold, color='r', linestyle='--', label="Threshold")
    plt.title("Phase Variance Across Segments")
    plt.xlabel("Segment Index")
    plt.ylabel("Phase Variance")
    plt.legend()
    
    # Biểu đồ entropy pha
    plt.subplot(3, 1, 2)
    plt.plot(phase_entropies, label="Phase Entropy")
    plt.title("Phase Entropy Across Segments")
    plt.xlabel("Segment Index")
    plt.ylabel("Phase Entropy")
    plt.legend()
    
    # Biểu đồ tự tương quan
    plt.subplot(3, 1, 3)
    plt.plot(autocorr, label="Autocorrelation")
    plt.plot(peaks, autocorr[peaks], "x", label="Peaks")
    plt.title("Autocorrelation of Phase Variance")
    plt.xlabel("Lag")
    plt.ylabel("Autocorrelation")
    plt.legend()
    
    plt.tight_layout()
    plt.show()
    
    # Kết luận
    print("\nAnalysis Summary:")
    if len(anomalies) > 0:
        print(f"- Found {len(anomalies)} segments with anomalous phase variance (above threshold).")
    else:
        print("- No segments with anomalous phase variance detected.")
    
    if len(peaks) > 0:
        print(f"- Detected {len(peaks)} peaks in autocorrelation, suggesting possible periodic patterns.")
    else:
        print("- No significant periodic patterns detected in phase variance.")
    
    if mean_entropy < 3.0 or std_entropy < 0.1:  # Giá trị tham khảo, có thể điều chỉnh
        print("- Low phase entropy or stable entropy, which is unusual and may indicate hidden data.")
    else:
        print("- Phase entropy appears normal.")
    
    # Đưa ra kết luận cuối cùng
    if len(anomalies) > 5 or len(peaks) > 0 or mean_entropy < 3.0:
        print("\nConclusion: The file is LIKELY to contain hidden data (possible phase coding).")
    else:
        print("\nConclusion: The file is UNLIKELY to contain hidden data.")

# Sử dụng
audio_file = "/home/ubuntu/audio/output-pc.wav"  # Thay bằng đường dẫn đến file âm thanh của bạn
analyze_phase(audio_file)
