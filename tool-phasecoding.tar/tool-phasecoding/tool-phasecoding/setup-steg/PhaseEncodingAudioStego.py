import os.path
import numpy as np
from scipy.io import wavfile
from AudioStegnographyAlgorithm import AudioStego

class PhaseEncodingAudioStego(AudioStego):
    def encodeAudio(self, audioLocation, stringToEncode) -> str:
        self.convertToByteArray(audioLocation)
        stringToEncode = stringToEncode.ljust(100, '~')
        textLength = 8 * len(stringToEncode)
        blockLength = int(2 * 2 ** np.ceil(np.log2(2 * textLength)))
        blockNumber = int(np.ceil(self.audioData.shape[0] / blockLength))
        if len(self.audioData.shape) == 1:
            print("1")
            self.audioData.resize(blockNumber * blockLength, refcheck=False)
            self.audioData = self.audioData[np.newaxis]
        else:
            print("2")
            self.audioData.resize((blockNumber * blockLength, self.audioData.shape[1]), refcheck=False)
            self.audioData = self.audioData.T

        blocks = self.audioData[0].reshape((blockNumber, blockLength))
        # Check chia_segment: Ki      ^cm tra k      ch th            ^{c block h         p l      ^g
        if blocks.shape == (blockNumber, blockLength):
            print("Thanh cong chia_segment")
        else:
            print("That bai chia_segment")
        blocks = np.fft.fft(blocks)
        # Check DFT_code: Ki      ^cm tra DFT kh      ng r      ^wng
        if blocks.size > 0 and np.iscomplexobj(blocks):
            print("Thanh cong DFT_code")
        else:
            print("That bai DFT_code")
        magnitudes = np.abs(blocks)
        phases = np.angle(blocks)
        phaseDiffs = np.diff(phases, axis=0)
        # Check diff_phase: Ki      ^cm tra phaseDiffs c       k      ch th            ^{c h         p l      ^g
        if phaseDiffs.shape[0] == blockNumber - 1 and phaseDiffs.shape[1] == blockLength:
            print("Thanh cong diff_phase")
        else:
            print("That bai diff_phase")
        textInBinary = np.ravel([[int(y) for y in format(ord(x), "08b")] for x in stringToEncode])
        textInPi = textInBinary.copy()
        textInPi[textInPi == 0] = -1
        textInPi = textInPi * -np.pi / 2
        blockMid = blockLength // 2
        phases[0, blockMid - textLength: blockMid] = textInPi
        phases[0, blockMid + 1: blockMid + 1 + textLength] = -textInPi[::-1]
        # Check embed_phase: Ki      ^cm tra pha    ^q         u ti      n    ^q               c thay    ^q      ^ui
        if np.any(phases[0, blockMid - textLength: blockMid] != 0):
            print("Thanh cong embed_phase")
        else:
            print("That bai embed_phase")
        for i in range(1, len(phases)):
            phases[i] = phases[i - 1] + phaseDiffs[i - 1]
        blocks = (magnitudes * np.exp(1j * phases))
        blocks = np.fft.ifft(blocks).real
        self.audioData[0] = blocks.ravel().astype(np.int16)
        return self.saveToLocation(self.audioData.T, audioLocation)
    
    def decodeAudio(self, audioLocation) -> str:
        self.convertToByteArray(audioLocation)
        textLength = 800
        blockLength = 2 * int(2 ** np.ceil(np.log2(2 * textLength)))
        blockMid = blockLength // 2
        if len(self.audioData.shape) == 1:
            secret = self.audioData[:blockLength]
        else:
            secret = self.audioData[:blockLength, 0]
        secretPhases = np.angle(np.fft.fft(secret))[blockMid - textLength:blockMid]
        secretInBinary = (secretPhases < 0).astype(np.int8)
        secretInIntCode = secretInBinary.reshape((-1, 8)).dot(1 << np.arange(8 - 1, -1, -1))
        decoded_message = "".join(np.char.mod("%c", secretInIntCode)).replace("~", "")
        # Check decode_code: Ki      ^cm tra decoded_message kh      ng r      ^wng
        if decoded_message:
            print("Thanh cong decode_code")
        else:
            print("That bai decode_code")
        # Ghi th      ng    ^qi      ^gp v      o file out_put_mess.txt
        with open("out_put_mess.txt", "w") as f:
            f.write(decoded_message)
        print(decoded_message)  # In ra stdout    ^q      ^c checkwork ki      ^cm tra B21DCAT070
        return decoded_message

    def convertToByteArray(self, audio):
        try:
            self.rate, self.audioData = wavfile.read(audio)
        except:
            pass
        self.audioData = self.audioData.copy()

    def saveToLocation(self, audioArray, location) -> str:
        dir = os.path.dirname(location)
        output_path = dir + "/output-pc.wav"
        wavfile.write(output_path, self.rate, audioArray)
        # Ki      ^cm tra file    ^q       t         o th      nh c      ng
        if os.path.exists(output_path):
            print("Thanh cong output_created")
        else:
            print("That bai output_created")
        return output_path
